RSGShared.Locations = {
    -- Base game ipl interiors
}
